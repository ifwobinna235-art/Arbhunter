# Arb Hunter — Live API Starter

## What this version does
- Keeps your provider API key on the server, not in browser JavaScript.
- Searches upcoming matches using a provider's arbitrage-search endpoint.
- Requests an arbitrage scan for a selected match and stake.
- Shows the provider's returned timestamp, market analysis and potential opportunities.

## Important limitations
- This project is an integration starter, not a verified live service. It does not include an API key and will not return live odds until you configure one.
- The example adapter is for BetRelay's documented API. Its documentation says the dedicated `/arbitrage` and `/arbitrage/search` endpoints require Pro or Enterprise access.
- Provider documentation currently lists SportyBet, Football.com and 1xBet in basic odds access; broader bookmaker access is plan-dependent. BetPawa is not listed in the documented odds-comparison bookmaker list. Confirm coverage and terms with the provider before paying.
- The API's documented cache can be about 3 minutes. Always re-check odds directly at each bookmaker before considering any bet.
- This version searches for a team name and scans selected matches; it does NOT independently enumerate and scan every event across all leagues. Provider-documented automatic email alerts may be a separate paid feature.
- No bet placement or bookmaker login is implemented.

## Run locally (computer or hosted Node.js environment)
1. Install Node.js 20 or newer.
2. Extract the ZIP and open a terminal in the project folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your API key in `.env` as `BETRELAY_API_KEY=...`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Security
- Never paste an API key into the public HTML, send it in a screenshot, or share it in chat.
- Keep `.env` private and do not upload it to GitHub.
- For hosting, store the key in the host's secret/environment-variable settings.
- Before purchasing any plan, verify the provider's current pricing, supported bookies for Nigeria, data freshness, API limits, and refund/usage terms.

## Provider docs checked for this starter
https://betrelay.com.ng/api-docs
