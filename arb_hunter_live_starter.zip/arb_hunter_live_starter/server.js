import express from "express";
import dotenv from "dotenv";

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.BETRELAY_API_KEY;
const BASE = "https://betrelay.com.ng/api/v1";

app.use(express.json({ limit: "20kb" }));
app.use(express.static("public"));

async function providerGet(path) {
  if (!API_KEY) {
    const err = new Error("Missing BETRELAY_API_KEY. Add your provider key to the server .env file.");
    err.status = 503;
    throw err;
  }
  const response = await fetch(`${BASE}${path}`, {
    headers: { "X-API-Key": API_KEY, "Accept": "application/json" },
    signal: AbortSignal.timeout(12000)
  });
  const raw = await response.text();
  let data;
  try { data = JSON.parse(raw); } catch { data = { message: raw.slice(0, 300) }; }
  if (!response.ok) {
    const err = new Error(data?.error || data?.message || `Odds provider returned HTTP ${response.status}`);
    err.status = response.status;
    throw err;
  }
  return data;
}

app.get("/api/status", async (_req, res) => {
  if (!API_KEY) return res.json({ configured: false, message: "No provider key configured. Live scanning is off." });
  try {
    const data = await providerGet("/usage");
    res.json({ configured: true, provider: "BetRelay", usage: data.data || data, message: "Provider key accepted by usage endpoint. This does not yet prove every target bookmaker/market is covered." });
  } catch (e) {
    res.status(e.status || 502).json({ configured: true, error: e.message });
  }
});

app.get("/api/search", async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    if (q.length < 3) return res.status(400).json({ error: "Enter at least 3 characters of a team name." });
    const data = await providerGet(`/arbitrage/search?q=${encodeURIComponent(q)}`);
    res.json(data);
  } catch (e) {
    res.status(e.status || 502).json({ error: e.message, providerStatus: e.status || null });
  }
});

app.get("/api/scan", async (req, res) => {
  try {
    const home = String(req.query.home || "").trim();
    const away = String(req.query.away || "").trim();
    const competition = String(req.query.competition || "").trim();
    const stake = Number(req.query.stake || 10000);
    if (!home || !away) return res.status(400).json({ error: "Home and away team names are required." });
    if (!Number.isFinite(stake) || stake < 100 || stake > 10000000) return res.status(400).json({ error: "Stake must be between 100 and 10,000,000." });
    const params = new URLSearchParams({ home, away, stake: String(stake) });
    if (competition) params.set("competition", competition);
    const data = await providerGet(`/arbitrage?${params.toString()}`);
    res.json(data);
  } catch (e) {
    res.status(e.status || 502).json({ error: e.message, providerStatus: e.status || null });
  }
});

app.listen(PORT, () => console.log(`Arb Hunter running on http://localhost:${PORT}`));
